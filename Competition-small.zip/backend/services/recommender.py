"""
推荐评分引擎
"""
from typing import List, Dict
from models.schemas import Book, BookScore, UserInput, Memory, Language
from config import settings
from utils.scorer import normalise_memory_value


class Recommender:
    """推荐引擎：基于评分公式的可解释推荐"""

    def __init__(self):
        pass

    def recommend(
        self,
        books: List[Book],
        user_input: UserInput,
        memories: List[Memory]
    ) -> List[BookScore]:
        """
        推荐评分

        评分公式：
        book_score = topic_match * W1 + difficulty_match * W2 + time_match * W3 + preference_match * W4 - rejection_penalty

        Args:
            books: 候选书目
            user_input: 用户输入
            memories: 相关记忆

        Returns:
            排序后的 BookScore 列表
        """
        scored_books = []

        for book in books:
            scores = self._calculate_scores(book, user_input, memories)

            # 检查是否被拒绝
            rejection_penalty = self._check_rejection(book, memories)

            # 计算总分
            total = (
                scores["topic"] * settings.weight_topic +
                scores["difficulty"] * settings.weight_difficulty +
                scores["time"] * settings.weight_time +
                scores["preference"] * settings.weight_preference -
                rejection_penalty * settings.rejection_penalty
            )

            # 生成解释
            explanation = self._generate_explanation(book, scores, rejection_penalty, memories)

            scored_books.append(BookScore(
                book=book,
                total_score=round(total, 2),
                topic_score=round(scores["topic"], 2),
                difficulty_score=round(scores["difficulty"], 2),
                time_score=round(scores["time"], 2),
                preference_score=round(scores["preference"], 2),
                explanation=explanation
            ))

        # 排序
        scored_books.sort(key=lambda x: x.total_score, reverse=True)

        return scored_books

    def _calculate_scores(self, book: Book, user_input: UserInput, memories: List[Memory]) -> Dict[str, float]:
        """计算各项评分（0-1）"""

        # 1. 主题匹配度（0-1）
        topic_score = self._score_topic(book, user_input.goal)

        # 2. 难度匹配度（0-1）
        difficulty_score = self._score_difficulty(book, user_input.difficulty, memories)

        # 3. 时间匹配度（0-1）
        time_score = self._score_time(book, user_input.time_per_day)

        # 4. 偏好匹配度（0-1）
        preference_score = self._score_preference(book, user_input, memories)

        return {
            "topic": topic_score,
            "difficulty": difficulty_score,
            "time": time_score,
            "preference": preference_score
        }

    def _score_topic(self, book: Book, user_goal: str) -> float:
        """主题匹配评分"""
        # 精确匹配
        if book.topic == user_goal:
            return 1.0

        # 中文主题关键词关联映射（跨主题弱匹配）
        goal_keywords = {
            "机器学习": ["深度学习", "人工智能", "算法", "数据结构", "Python基础", "统计"],
            "深度学习": ["机器学习", "人工智能", "算法", "神经网络"],
            "人工智能": ["机器学习", "深度学习", "算法"],
            "Python基础": ["算法", "数据结构", "机器学习", "软件工程"],
            "C/C++": ["算法", "数据结构", "操作系统", "嵌入式"],
            "Java": ["算法", "数据结构", "软件工程", "数据库"],
            "算法": ["数据结构", "Python基础", "C/C++", "Java", "离散数学"],
            "数据结构": ["算法", "Python基础", "C/C++", "Java"],
            "操作系统": ["数据结构", "算法", "计算机网络", "数据库"],
            "计算机网络": ["操作系统", "数据结构", "通信原理"],
            "数据库": ["数据结构", "算法", "软件工程"],
            "软件工程": ["数据库", "数据结构", "算法", "Python基础"],
        }

        keywords = goal_keywords.get(user_goal, [user_goal])
        book_text = f"{book.topic} {book.title} {book.description or ''} {' '.join(book.keywords)}".lower()

        matches = sum(1 for kw in keywords if kw.lower() in book_text)
        if matches > 0:
            return 0.7 + 0.3 * min(matches / len(keywords), 1.0)

        return 0.0

    def _score_difficulty(self, book: Book, user_difficulty: str, memories: List[Memory] = None) -> float:
        """难度匹配评分（记忆里的"太难/太简单"会微调目标难度）"""
        difficulty_order = {"beginner": 1, "intermediate": 2, "advanced": 3}
        book_level = difficulty_order.get(book.difficulty, 2)
        user_level = difficulty_order.get(user_difficulty, 2)

        # 记忆里的难度偏好：prefer_easier 降一级，prefer_harder 升一级
        for mem in memories or []:
            if mem.field == "difficulty":
                value = normalise_memory_value(mem.value)
                if value == "prefer_easier":
                    user_level = max(1, user_level - 1)
                elif value == "prefer_harder":
                    user_level = min(3, user_level + 1)

        diff = abs(book_level - user_level)
        if diff == 0:
            return 1.0
        elif diff == 1:
            return 0.6
        return 0.2

    def _score_time(self, book: Book, daily_minutes: int) -> float:
        """时间适配评分"""
        # 估算阅读速度：慢速读者 10页/30min，快速 20页/30min
        daily_pages_slow = daily_minutes / 3  # 30分钟10页
        daily_pages_fast = daily_minutes / 1.5  # 30分钟20页

        # 推荐阅读天数：7-30天
        ideal_days = 14
        ideal_pages = book.pages / ideal_days

        # 判断是否在合理范围内
        if daily_pages_slow <= ideal_pages <= daily_pages_fast:
            return 1.0
        elif daily_pages_slow * 0.5 <= ideal_pages <= daily_pages_fast * 1.5:
            return 0.7
        else:
            return 0.4

    def _score_preference(self, book: Book, user_input: UserInput, memories: List[Memory]) -> float:
        """偏好匹配评分（语言、内容风格的长期记忆都会生效）"""
        score = 0.5  # 基础分

        # 语言：本次选择优先，其次记忆里的长期语言偏好
        effective_lang = user_input.language
        lang_pref = next((m for m in memories if m.field == "language"), None)
        if lang_pref:
            value = normalise_memory_value(lang_pref.value)
            if value == "prefer_english":
                effective_lang = Language.EN
            elif value == "prefer_chinese":
                effective_lang = Language.ZH

        if book.language == effective_lang:
            score += 0.2
        else:
            score -= 0.1

        # 内容风格：规则压缩把偏好存成 field="format", value="prefer_cases"/"prefer_theory"
        format_pref = next((m for m in memories if m.field == "format"), None)
        if format_pref:
            value = normalise_memory_value(format_pref.value)
            if value == "prefer_cases" and book.case_ratio >= 0.6:
                score += 0.15
            if value == "prefer_theory" and book.theory_ratio >= 0.6:
                score += 0.15

        # 兼容旧格式（field 直接就是 prefer_cases / prefer_theory）
        if any(m.field == "prefer_cases" for m in memories) and book.case_ratio >= 0.6:
            score += 0.15
        if any(m.field == "prefer_theory" for m in memories) and book.theory_ratio >= 0.6:
            score += 0.15

        return max(0.0, min(1.0, score))

    def _check_rejection(self, book: Book, memories: List[Memory]) -> float:
        """检查是否被拒绝（返回惩罚分数）"""
        rejection_memories = [m for m in memories if m.field in ["rejected_book", "too_thick", "too_difficult"]]

        for mem in rejection_memories:
            # 如果记忆提到这本书的ID或关键词
            if str(book.id) in str(mem.value):
                return 1.0

            # 关键词匹配
            if any(kw.lower() in str(mem.value).lower() for kw in book.keywords):
                return 0.8

            if book.title in str(mem.value):
                return 1.0

        return 0.0

    def _generate_explanation(self, book: Book, scores: Dict, rejection: float, memories: List[Memory]) -> str:
        """生成推荐解释"""
        parts = []

        if scores["topic"] >= 0.7:
            parts.append(f"✓ 主题匹配：{book.topic}")
        if scores["difficulty"] >= 0.7:
            parts.append(f"✓ 难度合适：{book.difficulty}")
        if scores["time"] >= 0.7:
            parts.append(f"✓ 时间适配：{book.pages}页")
        if scores["preference"] >= 0.7:
            parts.append(f"✓ 符合偏好")

        if rejection > 0:
            parts.append(f"⚠ 您曾反馈过类似书籍{'不适合' if rejection > 0.5 else '可能不太适合'}")

        if not parts:
            parts.append("一般匹配")

        return "；".join(parts)


# 全局服务实例
recommender = Recommender()
