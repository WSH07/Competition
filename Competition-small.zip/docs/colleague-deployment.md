# 知遇 AI 馆员 - 同事部署说明

## 前置要求

- **Python 3.10 或更高版本**（建议 3.11/3.12）
- **Node.js 18 或更高版本**（建议 20 LTS）
- Windows 10/11

如果还没有安装，去官网下载：
- Python：https://www.python.org/downloads/
- Node.js：https://nodejs.org/zh-cn

安装时请务必勾选 **"Add to PATH" / "添加到环境变量"**。

## 部署步骤

### 1. 解压压缩包

把 `Competition-项目完整包.zip` 解压到任意位置，例如桌面，得到一个文件夹：

```
灵犀0.15-修复详情弹窗/
├── backend/
├── frontend/
├── scripts/
│   ├── start.py
│   ├── start.bat
│   └── diagnose.py
├── setup.py
└── data/
    └── 书库1.xlsx
```

### 2. 安装环境（只做一次）

**推荐方式：双击运行 `scripts/start.bat`**

首次运行会自动检测环境、创建虚拟环境并安装依赖，等待几分钟即可。

如果自动安装失败，也可以手动打开命令行执行：

```bash
cd 灵犀0.15-修复详情弹窗
python setup.py
```

> 说明：后端会用 `backend/.venv` 创建独立虚拟环境；前端如果检测到 `node_modules` 缺失会自动 `npm install`。

### 3. 启动项目

安装完成后，每次启动直接双击：

```
scripts/start.bat
```

或者命令行：

```bash
python scripts/start.py
```

启动成功后会自动打开两个黑色命令行窗口：
- **后端**：端口 8000
- **前端**：端口 5173

然后浏览器访问：

```
http://127.0.0.1:5173
```

## 常见问题

### 1. 提示找不到 Python / npm

- 检查安装时是否勾选了 "添加到 PATH"。
- 打开一个新的命令行窗口再试，环境变量修改后需要新窗口才生效。

### 2. `npm install` 很慢或失败

脚本会自动尝试淘宝镜像，如果仍然失败，手动进入 `frontend` 运行：

```bash
npm config set registry https://registry.npmmirror.com
npm install
```

### 3. pip 安装失败

脚本会自动尝试清华镜像，如果仍然失败，手动运行：

```bash
cd backend
python -m venv .venv
.venv\Scripts\python.exe -m pip install -r requirements.txt -i https://pypi.tuna.tsinghua.edu.cn/simple
```

### 4. 提示端口被占用

如果有其他程序占用了 8000 或 5173，关闭占用程序后重试。或者修改 `backend/config.py` 里的端口设置。

### 5. 推荐解释的 LLM 功能

默认不配置也能用，推荐解释和记忆压缩会走**规则兜底**。

如需更强的 LLM 解释，在 `backend/.env` 里填入：

```env
OPENAI_API_KEY=sk-你的key
```

然后重启后端即可。
